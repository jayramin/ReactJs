import React from 'react';
import  App  from "../component/App";

class Contact extends React.Component {
   render() {
      return (
         <div>
            <App/>
         	{/* <a href='/'>Home</a>&nbsp;| &nbsp;
            <a href='about'>About Us</a>&nbsp;| &nbsp;
            <a href='contact'>Contact Us</a> */}
            <h1>Contact</h1>
         </div>
      )
   }
}
export default Contact;
